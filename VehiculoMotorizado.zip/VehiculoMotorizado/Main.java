public class Main {
    
    public static void main(String[] args){

        Motocicleta m = new Motocicleta("Tomas", "Peugeot", 2012, 1000, "Repartir pedidos");
        Camion c = new Camion("Fabian", "Renault", 2004, 10000, 6, 3, 4);
        Automovil a = new AutomovilNormal("Alberto", "Chevrolet", 2016, 1500, 5);
        Automovil v = new Van("Rodrigo", "Volkswagen", 2020, 800, 3);

        System.out.println(m.getModelo());
        System.out.println(c.getModelo());
        System.out.println(a.getModelo());
        System.out.println(v.getModelo());

        System.out.println(m.getUso());
        System.out.println(c.getMaximoDePasajeros());
        System.out.println(a.getMaximoDePasajeros());
        System.out.println(v.getMaximoDePasajeros());
    }

}
