public class Van extends Automovil{
    
    public Van(String fabricante, String modelo, int añoDeFabricacion, double kilometraje, int maximoDePasajeros){
        super(fabricante, modelo, añoDeFabricacion, kilometraje, maximoDePasajeros);
    }

    @Override
    public String getFabricante(){
        return fabricante;
    }

    @Override
    public String getModelo(){
        return modelo;
    }

    @Override
    public int getAñoDeFabricacion(){
        return añoDeFabricacion;
    }

    @Override
    public double getKilometraje(){
        return kilometraje;
    }

    @Override
    public int getMaximoDePasajeros(){
        return this.maximoDePasajeros;
    }

}
