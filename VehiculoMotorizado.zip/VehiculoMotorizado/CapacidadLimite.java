interface CapacidadLimite {

    int getMaximoDePasajeros();

}
