public abstract class VehiculoMotorizado {
    
    protected String fabricante;
    protected String modelo;
    protected int añoDeFabricacion;
    protected double kilometraje;

    public VehiculoMotorizado(String fab, String mod, int año, double kil){
        this.fabricante = fab;
        this.modelo = mod;
        this.añoDeFabricacion = año;
        this.kilometraje = kil;
    }

    public abstract String getFabricante();

    public abstract String getModelo();

    public abstract int getAñoDeFabricacion();

    public abstract double getKilometraje();

}
