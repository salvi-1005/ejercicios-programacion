public class Camion extends VehiculoMotorizado implements CapacidadLimite{
    
    private int maximoDePasajeros;
    private int nivelDeSeguridad;
    private int cantRemolques;

    public Camion(String fabricante, String modelo, int añoDeFabricacion, double kilometraje, int max, int seg, int rem){
        super(fabricante, modelo, añoDeFabricacion, kilometraje);
        this.maximoDePasajeros = max;
        this.nivelDeSeguridad = seg;
        this.cantRemolques = rem;
    }

    @Override
    public String getFabricante(){
        return fabricante;
    }

    @Override
    public String getModelo(){
        return modelo;
    }

    @Override
    public int getAñoDeFabricacion(){
        return añoDeFabricacion;
    }

    @Override
    public double getKilometraje(){
        return kilometraje;
    }

    public int getMaximoDePasajeros(){
        return this.maximoDePasajeros;
    }

    public int getNivelDeSeguridad(){
        return this.nivelDeSeguridad;
    }

    public int getCantRemolques(){
        return this.cantRemolques;
    }

}
