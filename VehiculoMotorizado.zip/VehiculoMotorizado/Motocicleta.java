public class Motocicleta extends VehiculoMotorizado {
    
    private String uso;

    public Motocicleta(String fabricante, String modelo, int añoDeFabricacion, double kilometraje, String us){
        super(fabricante, modelo, añoDeFabricacion, kilometraje);
        this.uso = us;
    }

    @Override
    public String getFabricante(){
        return fabricante;
    }

    @Override
    public String getModelo(){
        return modelo;
    }

    @Override
    public int getAñoDeFabricacion(){
        return añoDeFabricacion;
    }

    @Override
    public double getKilometraje(){
        return kilometraje;
    }

    public String getUso(){
        return this.uso;
    }

}
