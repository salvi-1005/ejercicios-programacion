class CazaRojo extends Enemigo {
  int estado = 0; 
  String ladoOrigen; 
  float centroX, centroY;
  float radio = 80;
  float angulo;
  float velocidadAngular = 0.08;
  float anguloInicial;
  float anguloRecorrido = 0;

  CazaRojo(float x, float y, String lado) {
    super(x, y, 25, 25, 4.5, 1, 150);
    this.ladoOrigen = lado;

    if (ladoOrigen.equals("izquierda")) {
      centroX = 200;
      centroY = y + 80;
      anguloInicial = PI;
      angulo = anguloInicial;
    } else {
      centroX = width - 200;
      centroY = y + 80;
      anguloInicial = 0;
      angulo = anguloInicial;
    }
  }

  void actualizar() {
    if (estado == 0) {
      if (ladoOrigen.equals("izquierda")) {
        x += velocidad;
        if (x >= centroX - radio) {
          estado = 1;
          angulo = PI;
          anguloRecorrido = 0;
        }
      } else {
        x -= velocidad;
        if (x <= centroX + radio) {
          estado = 1;
          angulo = 0;
          anguloRecorrido = 0;
        }
      }
    } 
    else if (estado == 1) {
      if (ladoOrigen.equals("izquierda")) {
        angulo += velocidadAngular;
        anguloRecorrido += velocidadAngular;
        x = centroX + radio * cos(angulo);
        y = centroY + radio * sin(angulo);
        if (anguloRecorrido >= TWO_PI) {
          estado = 2;
        }
      } else {
        angulo -= velocidadAngular;
        anguloRecorrido += velocidadAngular;
        x = centroX + radio * cos(angulo);
        y = centroY + radio * sin(angulo);
        if (anguloRecorrido >= TWO_PI) {
          estado = 2;
        }
      }
    } 
    else if (estado == 2) {
      if (ladoOrigen.equals("izquierda")) {
        x += velocidad;
        y -= velocidad * 0.5;
      } else {
        x -= velocidad;
        y -= velocidad * 0.5;
      }

      if (x < -50 || x > width + 50 || y < -50 || y > height + 50) {
        desactivar();
      }
    }

    if (y > height) {
      desactivar();
    }
  }

  void dibujar() {
    fill(255, 50, 50);
    rect(x, y, ancho, alto);
  }
}
