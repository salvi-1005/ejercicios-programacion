class BateriaEnemiga extends Enemigo {

  int tiempoUltimoDisparo;
  int cadenciaDisparo;

  BateriaEnemiga(float x, float y) {
    super(x, y, 45, 95, 1, 10, 200);
    tiempoUltimoDisparo = 0;
    cadenciaDisparo = 2500;
  }

  void actualizar() {
    mover();

    if (y > height) {
      desactivar();
    }

    if (puedeDisparar()) {
      dispararHaciaJugador();
    }
  }

  void mover() {
    y += velocidad;
  }

  boolean puedeDisparar() {
    return millis() - tiempoUltimoDisparo >= cadenciaDisparo;
  }

    void dispararHaciaJugador() {
    tiempoUltimoDisparo = millis();
    float origenX = x + ancho / 2;
    float origenY = y + alto / 2;
    float objetivoX = juego.jugador.x + juego.jugador.ancho / 2;
    float objetivoY = juego.jugador.y + juego.jugador.alto / 2;
    float anguloBase = atan2(objetivoY - origenY, objetivoX - origenX);
    float velocidadProyectil = 2.0;
    float[] dispersion = {-0.25, 0, 0.25};

    for (float offset : dispersion) {
      float angulo = anguloBase + offset;
      float vx = cos(angulo) * velocidadProyectil;
      float vy = sin(angulo) * velocidadProyectil;
      juego.elementos.add(new ProyectilEnemigo(origenX, origenY, vx, vy));
    }
  }


  void dibujar() {
    fill(150, 80, 255);
    rect(x, y, ancho, alto);
  }
}
