class CazaPesado extends Enemigo {
  int tiempoUltimoDisparo;
  int cadenciaDisparo;

  CazaPesado(float x, float y) {
    super(x, y, 75, 45, 2, 8, 300);
    tiempoUltimoDisparo = 0;
    cadenciaDisparo = 2000;
  }

  void actualizar() {
    mover();

    if (y > height) {
      desactivar();
    }

    if (puedeDisparar()) {
      dispararDoble();
    }
  }

  void mover() {
    y += velocidad;
  }

  boolean puedeDisparar() {
    return y > 0 && millis() - tiempoUltimoDisparo >= cadenciaDisparo;
  }

  void dispararDoble() {
    tiempoUltimoDisparo = millis();
  
    ProyectilEnemigo p1 = new ProyectilEnemigo(x + 10, y + alto);
    ProyectilEnemigo p2 = new ProyectilEnemigo(x + ancho - 15, y + alto);
    juego.elementos.add(p1);
    juego.elementos.add(p2);
  }

  void dibujar() {
  
    fill(40, 120, 60);
    rect(x, y, ancho, alto);
    
    fill(70, 160, 90);
    rect(x - 10, y + 15, 10, 15);
    rect(x + ancho, y + 15, 10, 15);
    
    fill(100, 200, 255);
    rect(x + ancho / 2 - 5, y + 10, 10, 15);
  }
}
