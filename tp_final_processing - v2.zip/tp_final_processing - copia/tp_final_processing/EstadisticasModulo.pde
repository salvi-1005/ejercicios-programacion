import java.util.Map;
import java.util.HashMap;

class EstadisticasModulo extends EstadisticasGenerales {
  Map<String, Integer> valoresNumericos = new HashMap<String, Integer>();
  Map<String, String> valoresTexto = new HashMap<String, String>();

  int disparosTotales = 0;
  int disparosAcertados = 0;
  int rachaMaxDerribos = 0;
  int rachaActual = 0;
  int enemigosDerribados = 0;
  double precision = 0;

  EstadisticasModulo() {
    actualizarMapas();
  }

  void registrarDisparo(boolean acerto) {
    disparosTotales++;

    if (acerto) {
      disparosAcertados++;
    }

    calcularPrecision();
    actualizarMapas();
  }

  void registrarImpacto() {
    disparosAcertados++;
    calcularPrecision();
    actualizarMapas();
  }

  void registrarDerribo(int puntos) {
    enemigosDerribados++;
    puntajeTotal += puntos;
    enemigosDestruidos++;
    rachaActual++;

    if (rachaActual > rachaMaxDerribos) {
      rachaMaxDerribos = rachaActual;
    }

    calcularPrecision();
    actualizarMapas();
  }

  void registrarMuerteJugador() {
    rachaActual = 0;
    actualizarMapas();
  }

  double calcularPrecision() {
    if (disparosTotales == 0) {
      precision = 0;
    } else {
      precision = (disparosAcertados * 100.0) / disparosTotales;
    }

    return precision;
  }

  void agregarValorNumerico(String clave, int valor) {
    valoresNumericos.put(clave, valor);
  }

  void agregarValorTexto(String clave, String valor) {
    valoresTexto.put(clave, valor);
  }

  int obtenerValorNumerico(String clave) {
    if (valoresNumericos.containsKey(clave)) {
      return valoresNumericos.get(clave);
    }
    return 0;
  }

  String obtenerValorTexto(String clave) {
    if (valoresTexto.containsKey(clave)) {
      return valoresTexto.get(clave);
    }
    return "";
  }

  void reiniciarEstadisticas() {
    super.reiniciarEstadisticas();
    disparosTotales = 0;
    disparosAcertados = 0;
    rachaMaxDerribos = 0;
    rachaActual = 0;
    enemigosDerribados = 0;
    precision = 0;
    valoresNumericos.clear();
    valoresTexto.clear();
    actualizarMapas();
  }

  void actualizarMapas() {
    agregarValorNumerico("disparosTotales", disparosTotales);
    agregarValorNumerico("disparosAcertados", disparosAcertados);
    agregarValorNumerico("rachaMaxDerribos", rachaMaxDerribos);
    agregarValorNumerico("rachaActual", rachaActual);
    agregarValorNumerico("enemigosDerribados", enemigosDerribados);
    agregarValorNumerico("puntajeTotal", puntajeTotal);

    agregarValorTexto("precision", nf((float)precision, 1, 2) + "%");
  }
}
