class CazaEnemigo extends Enemigo {
  int tiempoUltimoDisparo;
  int cadenciaDisparo;
  PImage img;

  CazaEnemigo(float x, float y) {
    super(x, y, 70, 70, 3, 1, 100);
    tiempoUltimoDisparo = 0;
    cadenciaDisparo = 2000;
    img = loadImage("CazaEnemigo.png");
  }

  void actualizar() {
    mover();
    if (y > height) desactivar();

    if (puedeDisparar()) {
      ProyectilEnemigo proyectil = disparar();
      juego.elementos.add(proyectil);
    }
  }

  void mover() {
    y += velocidad;
  }

  boolean puedeDisparar() {
    return y > 0 && millis() - tiempoUltimoDisparo >= cadenciaDisparo;
  }

  ProyectilEnemigo disparar() {
    tiempoUltimoDisparo = millis();
    return new ProyectilEnemigo(x + ancho / 2 - 4, y + alto);
  }

  void dibujar() {
    if (img != null) {
      image(img, x, y, ancho, alto);
    } else {
    fill(255, 80, 80);
    triangle(x, y, x + ancho, y, x + ancho / 2, y + alto);
    }
  }
}
