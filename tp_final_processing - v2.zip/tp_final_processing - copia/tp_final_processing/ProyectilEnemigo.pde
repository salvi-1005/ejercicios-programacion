class ProyectilEnemigo extends Proyectil {
  
  float vx;
  float vy;

  ProyectilEnemigo(float x, float y) {
    this(x, y, 0, 5.5);
  }
  ProyectilEnemigo(float x, float y, float vx, float vy) {
    super(x, y, 0, 1);
    this.vx = vx;
    this.vy = vy;
  }

  void actualizar() {
    mover();
    if (estaFueraDePantalla()) desactivar();
  }

  void mover() {
    x += vx;
    y += vy;
  }
  boolean estaFueraDePantalla() {
    return x < -20 || x > width + 20 || y < -20 || y > height + 20;
  }
  void dibujar() {
    fill(255, 0, 0);
    rect(x, y, ancho, alto);
  }
}
